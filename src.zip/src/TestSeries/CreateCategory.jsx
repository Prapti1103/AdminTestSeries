import React, { useState, useEffect } from "react";
import { Button, Modal, Form, Input, Table, message } from "antd";
import Swal from "sweetalert2";
import { DeleteOutlined} from "@ant-design/icons";
import {
  createVTCategory,
  GetAllCategories,
  updateVTCategory,
  deleteVTCategory,
} from "./TestSeriesAPI";
const CreateCategory = () => {
  const [form] = Form.useForm();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(false);
  const [editingId, setEditingId] = useState(null);

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      setLoading(true);
      console.log("Fetching categories...");
      const response = await GetAllCategories();
      console.log("Categories fetched:", response.data);
      setCategories(response.data);
    } catch (error) {
      console.error("Error fetching categories:", error);
      message.error("Failed to fetch categories");
    } finally {
      setLoading(false);
    }
  };

  const showModal = () => {
    setIsModalOpen(true);
    setEditingId(null);
    form.resetFields();
  };

  const handleEdit = (record) => {
    setIsModalOpen(true);
    setEditingId(record.id);
    form.setFieldsValue({
  category: record.name,
});
  };

  const handleCancel = () => {
    setIsModalOpen(false);
    form.resetFields();
    setEditingId(null);
  };

  const onFinish = async (values) => {
    try {
      console.log("Saving category:", values, "Edit mode:", editingId);
      if (editingId) {
        await updateVTCategory(editingId, {
  name: values.category,
});
        Swal.fire({
          title: "Success!",
          text: "Category updated successfully",
          icon: "success",
          confirmButtonText: "OK",
        });
      } else {
        await createVTCategory({
  name: values.category,
});
        Swal.fire({
          title: "Success!",
          text: "Category created successfully",
          icon: "success",
          confirmButtonText: "OK",
        });
      }

      setIsModalOpen(false);
      form.resetFields();
      setEditingId(null);
      fetchCategories();
    } catch (error) {
      console.error("Error saving category:", error);
      message.error(
        error.response?.data?.message || "Failed to save category"
      );
    }
  };

  const handleDelete = async (id) => {
    try {
      const result = await Swal.fire({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, delete it!",
      });

      if (result.isConfirmed) {
        console.log("Deleting category:", id);
        await deleteVTCategory(id);
        Swal.fire(
          "Deleted!",
          "Your category has been deleted.",
          "success"
        );
        fetchCategories();
      }
    } catch (error) {
      console.error("Error deleting category:", error);
      message.error("Failed to delete category");
    }
  };

  const columns = [
    {
      title: "ID",
      dataIndex: "id",
      key: "id",
    },
    {
  title: "Category",
  dataIndex: "name",
  key: "name",
  render: (text, record) => (
    <a onClick={() => handleEdit(record)}>{text}</a>
  ),
},
    {
      title: "Action",
      key: "action",
      render: (_, record) => (
        <Button
          danger
          icon={<DeleteOutlined />}
          onClick={() => handleDelete(record.id)}
        />
      ),
    },
  ];

  return (
    <div>
      <Button type="primary" onClick={showModal} style={{ marginBottom: 16 }}>
        Add Category
      </Button>

    <Table
  columns={columns}
  bordered
  size="small"
  dataSource={[...categories].reverse()}
  rowKey="id"
  loading={loading}
  pagination={{
    placement: "bottomRight",
    pageSize: 10,
    showSizeChanger: true,
    pageSizeOptions: [
      "1",
      "10",
      "25",
      "50",
      "100",
      "500",
      "1000",
    ],
    showTotal: (total, range) =>
      `${range[0]}-${range[1]} of ${total} items`,
  }}
/>

      <Modal
        title={editingId ? "Edit Category" : "Add Category"}
        open={isModalOpen}
        onCancel={handleCancel}
        footer={null}
      >
        <Form form={form} layout="vertical" onFinish={onFinish}>
          <Form.Item
            name="category"
            label="Category Name"
            rules={[{ required: true, message: "Please input the category name!" }]}
          >
            <Input />
          </Form.Item>

          <Form.Item>
            <Button type="primary" htmlType="submit">
              {editingId ? "Update" : "Submit"}
            </Button>
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export default CreateCategory;